import streamlit as st
import numpy as np 
import pandas as pd 
import matplotlib 
import plotly as pl

def load_data():
    pass

title = st.title("""##Hola! this is the first pywebpage""")


