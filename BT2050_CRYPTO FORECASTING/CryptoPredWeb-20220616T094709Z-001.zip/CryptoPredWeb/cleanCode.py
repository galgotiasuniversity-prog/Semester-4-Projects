# importing bas libraries
import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd
import pandas_datareader as web
import datetime as dt
import pandas as pd
import streamlit as st
import plotly as pl

# importing ml libs
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.layers import Dense, Dropout, LSTM
from tensorflow.keras.models import Sequential
from torch import inverse
from torch_optimizer import Optimizer

# selecting cryptocurrency and against_currency
crypto_currency = 'BTC'
against_currency = 'INR'

# Setting time-frame for training data
start = dt.datetime(2016,1,1)
end = dt.datetime.now()

# Loading data from mlpfinance 
data = web.DataReader(f'{crypto_currency}-{against_currency}','yahoo',start,end)
print(data.head())

# Data Preparation
    # Scaling data
scaler = MinMaxScaler(feature_range=(0,1))
scaled_data = scaler.fit_transform(data['close'].values.reshape(-1,1))