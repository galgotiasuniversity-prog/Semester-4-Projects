<h2>
CryptoPred App
</h2>

<p>
this is the setup for compiling the cryptopred python file to a Desktop App (.exe) using extentions py2exe. <br>
Currently, it is not working due to some error -_-.<br>
Working on the file to make it easy to compile and will be updated soon 😊.

</P>
