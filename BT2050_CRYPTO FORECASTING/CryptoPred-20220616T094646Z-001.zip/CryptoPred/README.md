# CryptoPred

<p>
this is a simple project that used Nueral Networks and predicts the price of a cryptocurrency in the selected comparater currency. Initially, this project predicts the closing price of the next day from current date.
The further versions will include a predicted graph of 'N' number of days and using other optimizer to check the accuracy of the model(currently using adam optimizer).
<br>
the dataset is directly fetched from Yahoo Finance using pandas_datareader according the start and end dates assigned.<br>

</p>
<br>
<p>
this project is inspired by a video from  youtuber NueralNine.
</p>
