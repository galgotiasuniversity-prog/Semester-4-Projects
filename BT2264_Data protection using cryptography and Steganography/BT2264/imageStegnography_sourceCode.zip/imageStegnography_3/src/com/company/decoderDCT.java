package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class decoderDCT extends DCT {

    BufferedImage hostImage = null;
    BufferedImage originalImage = null;
    BufferedImage encodedImage = null;

    int width;
    int height;

    int[][] dctMatrix = new int[N][N];
    double[][] output = new double[N][N];


    decoderDCT(BufferedImage hostImage,BufferedImage originalImage){
        super();
        this.hostImage =hostImage;
        this.originalImage = originalImage;
        this.width = hostImage.getWidth();
        this.height = hostImage.getHeight();

        encodedImage = new BufferedImage(this.width,this.height,BufferedImage.TYPE_INT_RGB);
        decode();

        try {
            ImageIO.write(encodedImage,"png",new File("userResources/xxx.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void decode(){
        for(int i=0;i<this.width;i+=8)
            for(int j=0;j<this.height;j+=8){

                //dctImageMatrix = initializeQuantization(applyDCT(getPixelMatrix(i,j,this.encodeImg)));
                //output = applyIDCT(initializeInverseQuantization(dctImageMatrix));


                for(int k=0;k<N;k++) {
                    for (int l = 0; l < N; l++) {

                        //int px = this.hostImage.getRGB(i+k,j+l)+dctImageMatrix[k][l];
                        int px = this.hostImage.getRGB(i + k, j + l) - this.originalImage.getRGB(i + k, j + l);
                        //this.imageOutput.setRGB(i+k,j+l,px);
                        dctMatrix[k][l] = px;
                        System.out.println((px&0xFF));

                    }
                    //System.out.println();
                }
                System.out.println("---------------------------");

                output = applyIDCT(initializeInverseQuantization(dctMatrix));

                for(int k=0;k<N;k++)
                    for(int l=0;l<N;l++){

                        encodedImage.setRGB(i+k,j+l, (int) output[k][l]);

                    }



            }

    }


}
