package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class encoderDCT extends DCT {

    BufferedImage hostImage = null;
    BufferedImage encodeImg = null;
    BufferedImage imageOutput = null;

    int width;
    int height;
    int[][] dctImageMatrix = new int[N][N];

    encoderDCT(BufferedImage hostImage,BufferedImage imageToEncode){
        super();
        this.hostImage =hostImage;
        this.width = hostImage.getWidth();
        this.height = hostImage.getHeight();

        imageOutput = new BufferedImage(this.width,this.height, BufferedImage.TYPE_INT_RGB);

        //setEncodeImgToHostImgDimension
        int widthSkip = (hostImage.getWidth()-imageToEncode.getWidth())/2;
        int heightSkip = (hostImage.getHeight()-imageToEncode.getHeight())/2;

        this.encodeImg = new BufferedImage(hostImage.getWidth(),hostImage.getHeight(),BufferedImage.TYPE_INT_RGB);

        //new img with host image width and height
        for(int i=0;i<imageToEncode.getWidth();i++)
            for(int j=0;j<imageToEncode.getHeight();j++)
                this.encodeImg.setRGB(i+ widthSkip,j+ heightSkip,imageToEncode.getRGB(i,j));
        //END-setEncodeImgToHostImgDimension


        encode();

        try {
            ImageIO.write(this.imageOutput,"png", new File("userResources/temp.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private void encode(){
        for(int i=0;i<this.width;i+=8)
            for(int j=0;j<this.height;j+=8){

                dctImageMatrix = initializeQuantization(applyDCT(getPixelMatrix(i,j,this.encodeImg)));
                //output = applyIDCT(initializeInverseQuantization(dctImageMatrix));


                for(int k=0;k<N;k++)
                    for(int l=0;l<N;l++){

                        int px = this.hostImage.getRGB(i+k,j+l)+dctImageMatrix[k][l];

                        System.out.println(px);
                        this.imageOutput.setRGB(i+k,j+l,px);
                    }
            }

    }

}
