package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
	// write your code here

        BufferedImage outputImage = new BufferedImage(8,8,BufferedImage.TYPE_BYTE_GRAY);
        System.out.println("11");
        BufferedImage hostImage = ImageIO.read(new File("userResources/host.png"));
        System.out.println("22");
        BufferedImage imgToEncode = ImageIO.read(new File("userResources/sample.png"));
        System.out.println("33");
        BufferedImage encodedImg = ImageIO.read(new File("userResources/temp.png"));
        System.out.println("44");

        encoderDCT encoderDCT = new encoderDCT(hostImage,imgToEncode);

        /*
        for(int k=0;k<hostImage.getWidth();k++)
            for(int l=0;l<hostImage.getHeight();l++){
                int px = encodedImg.getRGB(k,l) - hostImage.getRGB(k,l);
                System.out.print(px+" ");
            }

         */


    }
}
