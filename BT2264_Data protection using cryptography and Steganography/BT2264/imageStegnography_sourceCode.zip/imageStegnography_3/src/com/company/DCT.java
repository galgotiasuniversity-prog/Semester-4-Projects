package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static java.lang.Math.PI;

public class DCT {

    public int N = 8;
    //double[][] output = new double[N][N];
    public final double Ci[] = new double[N];
    public final double Cj[] = new double[N];

    public double[][] quantizationTable = {
            {16,    11,    10,    16,    24,    40,    51,    61},
            {12,    12,    14,    19,    26,    58,    60,    55},
            {14,    13,    16,    24,    40,    57,    69,    56},
            {14,    17,    22,    29,    51,    87,    80,    62},
            {18,    22,    37,    56,    68,   109,   103,    77},
            {24,    35,    55,    64,    81,   104,   113,    92},
            {49,    64,    78,    87,   103,   121,   120,   101},
            {72,    92,    95,    98,   112,   100,   103,    99}
    };

    BufferedImage imageDCT = null;



    DCT(){ initializeCoefficient(); }


    private void initializeCoefficient(){
        for(int i=0;i<N;i++){
            if(i==0)
                Ci[i]=1/Math.sqrt(N);
            else
                Ci[i]=Math.sqrt(2)/Math.sqrt(N);
        }
        for(int j=0;j<N;j++){
            if(j==0)
                Cj[j]=1/Math.sqrt(N);
            else
                Cj[j]=Math.sqrt(2)/Math.sqrt(N);

        }
    }

    protected double[][] getPixelMatrix(int indexX,int indexY, BufferedImage image){
        double token[][] = new double[N][N];

        //int indexX =208, indexY =104;
        //token
        {
            token[0][0] = image.getRGB(indexX + 0, indexY);
            token[0][1] = image.getRGB(indexX + 0, indexY + 1);
            token[0][2] = image.getRGB(indexX + 0, indexY + 2);
            token[0][3] = image.getRGB(indexX + 0, indexY + 3);
            token[0][4] = image.getRGB(indexX + 0, indexY + 4);
            token[0][5] = image.getRGB(indexX + 0, indexY + 5);
            token[0][6] = image.getRGB(indexX + 0, indexY + 6);
            token[0][7] = image.getRGB(indexX + 0, indexY + 7);

            token[1][0] = image.getRGB(indexX + 1, indexY);
            token[1][1] = image.getRGB(indexX + 1, indexY + 1);
            token[1][2] = image.getRGB(indexX + 1, indexY + 2);
            token[1][3] = image.getRGB(indexX + 1, indexY + 3);
            token[1][4] = image.getRGB(indexX + 1, indexY + 4);
            token[1][5] = image.getRGB(indexX + 1, indexY + 5);
            token[1][6] = image.getRGB(indexX + 1, indexY + 6);
            token[1][7] = image.getRGB(indexX + 1, indexY + 7);

            token[2][0] = image.getRGB(indexX + 2, indexY);
            token[2][1] = image.getRGB(indexX + 2, indexY + 1);
            token[2][2] = image.getRGB(indexX + 2, indexY + 2);
            token[2][3] = image.getRGB(indexX + 2, indexY + 3);
            token[2][4] = image.getRGB(indexX + 2, indexY + 4);
            token[2][5] = image.getRGB(indexX + 2, indexY + 5);
            token[2][6] = image.getRGB(indexX + 2, indexY + 6);
            token[2][7] = image.getRGB(indexX + 2, indexY + 7);

            token[3][0] = image.getRGB(indexX + 3, indexY);
            token[3][1] = image.getRGB(indexX + 3, indexY + 1);
            token[3][2] = image.getRGB(indexX + 3, indexY + 2);
            token[3][3] = image.getRGB(indexX + 3, indexY + 3);
            token[3][4] = image.getRGB(indexX + 3, indexY + 4);
            token[3][5] = image.getRGB(indexX + 3, indexY + 5);
            token[3][6] = image.getRGB(indexX + 3, indexY + 6);
            token[3][7] = image.getRGB(indexX + 3, indexY + 7);

            token[4][0] = image.getRGB(indexX + 4, indexY);
            token[4][1] = image.getRGB(indexX + 4, indexY + 1);
            token[4][2] = image.getRGB(indexX + 4, indexY + 2);
            token[4][3] = image.getRGB(indexX + 4, indexY + 3);
            token[4][4] = image.getRGB(indexX + 4, indexY + 4);
            token[4][5] = image.getRGB(indexX + 4, indexY + 5);
            token[4][6] = image.getRGB(indexX + 4, indexY + 6);
            token[4][7] = image.getRGB(indexX + 4, indexY + 7);

            token[5][0] = image.getRGB(indexX + 5, indexY);
            token[5][1] = image.getRGB(indexX + 5, indexY + 1);
            token[5][2] = image.getRGB(indexX + 5, indexY + 2);
            token[5][3] = image.getRGB(indexX + 5, indexY + 3);
            token[5][4] = image.getRGB(indexX + 5, indexY + 4);
            token[5][5] = image.getRGB(indexX + 5, indexY + 5);
            token[5][6] = image.getRGB(indexX + 5, indexY + 6);
            token[5][7] = image.getRGB(indexX + 5, indexY + 7);

            token[6][0] = image.getRGB(indexX + 6, indexY);
            token[6][1] = image.getRGB(indexX + 6, indexY + 1);
            token[6][2] = image.getRGB(indexX + 6, indexY + 2);
            token[6][3] = image.getRGB(indexX + 6, indexY + 3);
            token[6][4] = image.getRGB(indexX + 6, indexY + 4);
            token[6][5] = image.getRGB(indexX + 6, indexY + 5);
            token[6][6] = image.getRGB(indexX + 6, indexY + 6);
            token[6][7] = image.getRGB(indexX + 6, indexY + 7);

            token[7][0] = image.getRGB(indexX + 7, indexY);
            token[7][1] = image.getRGB(indexX + 7, indexY + 1);
            token[7][2] = image.getRGB(indexX + 7, indexY + 2);
            token[7][3] = image.getRGB(indexX + 7, indexY + 3);
            token[7][4] = image.getRGB(indexX + 7, indexY + 4);
            token[7][5] = image.getRGB(indexX + 7, indexY + 5);
            token[7][6] = image.getRGB(indexX + 7, indexY + 6);
            token[7][7] = image.getRGB(indexX + 7, indexY + 7);
        }

        //important
/*
        {
            token[0][0] = image.getRGB(indexX + 0, indexY) & 0xFF;
            token[0][1] = image.getRGB(indexX + 0, indexY + 1) & 0xFF;
            token[0][2] = image.getRGB(indexX + 0, indexY + 2) & 0xFF;
            token[0][3] = image.getRGB(indexX + 0, indexY + 3) & 0xFF;
            token[0][4] = image.getRGB(indexX + 0, indexY + 4) & 0xFF;
            token[0][5] = image.getRGB(indexX + 0, indexY + 5) & 0xFF;
            token[0][6] = image.getRGB(indexX + 0, indexY + 6) & 0xFF;
            token[0][7] = image.getRGB(indexX + 0, indexY + 7) & 0xFF;

            token[1][0] = image.getRGB(indexX + 1, indexY) & 0xFF;
            token[1][1] = image.getRGB(indexX + 1, indexY + 1) & 0xFF;
            token[1][2] = image.getRGB(indexX + 1, indexY + 2) & 0xFF;
            token[1][3] = image.getRGB(indexX + 1, indexY + 3) & 0xFF;
            token[1][4] = image.getRGB(indexX + 1, indexY + 4) & 0xFF;
            token[1][5] = image.getRGB(indexX + 1, indexY + 5) & 0xFF;
            token[1][6] = image.getRGB(indexX + 1, indexY + 6) & 0xFF;
            token[1][7] = image.getRGB(indexX + 1, indexY + 7) & 0xFF;

            token[2][0] = image.getRGB(indexX + 2, indexY) & 0xFF;
            token[2][1] = image.getRGB(indexX + 2, indexY + 1) & 0xFF;
            token[2][2] = image.getRGB(indexX + 2, indexY + 2) & 0xFF;
            token[2][3] = image.getRGB(indexX + 2, indexY + 3) & 0xFF;
            token[2][4] = image.getRGB(indexX + 2, indexY + 4) & 0xFF;
            token[2][5] = image.getRGB(indexX + 2, indexY + 5) & 0xFF;
            token[2][6] = image.getRGB(indexX + 2, indexY + 6) & 0xFF;
            token[2][7] = image.getRGB(indexX + 2, indexY + 7) & 0xFF;

            token[3][0] = image.getRGB(indexX + 3, indexY) & 0xFF;
            token[3][1] = image.getRGB(indexX + 3, indexY + 1) & 0xFF;
            token[3][2] = image.getRGB(indexX + 3, indexY + 2) & 0xFF;
            token[3][3] = image.getRGB(indexX + 3, indexY + 3) & 0xFF;
            token[3][4] = image.getRGB(indexX + 3, indexY + 4) & 0xFF;
            token[3][5] = image.getRGB(indexX + 3, indexY + 5) & 0xFF;
            token[3][6] = image.getRGB(indexX + 3, indexY + 6) & 0xFF;
            token[3][7] = image.getRGB(indexX + 3, indexY + 7) & 0xFF;

            token[4][0] = image.getRGB(indexX + 4, indexY) & 0xFF;
            token[4][1] = image.getRGB(indexX + 4, indexY + 1) & 0xFF;
            token[4][2] = image.getRGB(indexX + 4, indexY + 2) & 0xFF;
            token[4][3] = image.getRGB(indexX + 4, indexY + 3) & 0xFF;
            token[4][4] = image.getRGB(indexX + 4, indexY + 4) & 0xFF;
            token[4][5] = image.getRGB(indexX + 4, indexY + 5) & 0xFF;
            token[4][6] = image.getRGB(indexX + 4, indexY + 6) & 0xFF;
            token[4][7] = image.getRGB(indexX + 4, indexY + 7) & 0xFF;

            token[5][0] = image.getRGB(indexX + 5, indexY) & 0xFF;
            token[5][1] = image.getRGB(indexX + 5, indexY + 1) & 0xFF;
            token[5][2] = image.getRGB(indexX + 5, indexY + 2) & 0xFF;
            token[5][3] = image.getRGB(indexX + 5, indexY + 3) & 0xFF;
            token[5][4] = image.getRGB(indexX + 5, indexY + 4) & 0xFF;
            token[5][5] = image.getRGB(indexX + 5, indexY + 5) & 0xFF;
            token[5][6] = image.getRGB(indexX + 5, indexY + 6) & 0xFF;
            token[5][7] = image.getRGB(indexX + 5, indexY + 7) & 0xFF;

            token[6][0] = image.getRGB(indexX + 6, indexY) & 0xFF;
            token[6][1] = image.getRGB(indexX + 6, indexY + 1) & 0xFF;
            token[6][2] = image.getRGB(indexX + 6, indexY + 2) & 0xFF;
            token[6][3] = image.getRGB(indexX + 6, indexY + 3) & 0xFF;
            token[6][4] = image.getRGB(indexX + 6, indexY + 4) & 0xFF;
            token[6][5] = image.getRGB(indexX + 6, indexY + 5) & 0xFF;
            token[6][6] = image.getRGB(indexX + 6, indexY + 6) & 0xFF;
            token[6][7] = image.getRGB(indexX + 6, indexY + 7) & 0xFF;

            token[7][0] = image.getRGB(indexX + 7, indexY) & 0xFF;
            token[7][1] = image.getRGB(indexX + 7, indexY + 1) & 0xFF;
            token[7][2] = image.getRGB(indexX + 7, indexY + 2) & 0xFF;
            token[7][3] = image.getRGB(indexX + 7, indexY + 3) & 0xFF;
            token[7][4] = image.getRGB(indexX + 7, indexY + 4) & 0xFF;
            token[7][5] = image.getRGB(indexX + 7, indexY + 5) & 0xFF;
            token[7][6] = image.getRGB(indexX + 7, indexY + 6) & 0xFF;
            token[7][7] = image.getRGB(indexX + 7, indexY + 7) & 0xFF;
        }
 */



        //unnecessary
        printResult(token,"get pixel matrix");

        BufferedImage hostImage = new BufferedImage(8,8,BufferedImage.TYPE_BYTE_GRAY);

        //set host image
        for(int i =0;i<N;i++){
            for (int j=0;j<N;j++){
                hostImage.setRGB(i,j, (int) token[i][j]);
            }

        }

        try {
            ImageIO.write(hostImage,"jpg",new File("userResources/hostImage_8x8.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }



        return token;
    }

    protected double[][] applyDCT(double matrix[][]) {
        int i, j, k, l, N = 8;

        // dct will store the discrete cosine transform
        double[][] dct = new double[N][N];

        double ci, cj, dct1, sum;

        for (i = 0; i < N; i++) {
            for (j = 0; j < N; j++) {
                // ci and cj depends on frequency as well as
                // number of row and columns of specified matrix
/*
                if (i == 0)
                    ci = 1 / Math.sqrt(N);
                else
                    ci = Math.sqrt(2) / Math.sqrt(N);

                if (j == 0)
                    cj = 1 / Math.sqrt(N);
                else
                    cj = Math.sqrt(2) / Math.sqrt(N);


 */
                // sum will temporarily store the sum of
                // cosine signals
                sum = 0;
                for (k = 0; k < N; k++) {
                    for (l = 0; l < N; l++) {
                        dct1 = matrix[k][l] * Math.cos((2 * k + 1) * i * PI / (2 * N))
                                * Math.cos((2 * l + 1) * j * PI / (2 * N));
                        sum = sum + dct1;
                    }
                }
                dct[i][j] = Ci[i] * Cj[j] * sum;
            }
        }

        double[][] op = new double[8][8];
        for (int m = 0; m < dct.length; m++) {
            for (int m2 = 0; m2 < dct.length; m2++) {
                op[m][m2] = (int) dct[m][m2];
            }
        }

        //unnecessary
        printResult(op,"DCT");


        return op;
    }

    protected int[][] initializeQuantization(double[][] unQuantizedMatrix){
        int[][] result = new int[N][N];
        for(int i=0;i<N;i++)
            for(int j=0;j<N;j++){
                result[i][j]= (int) (unQuantizedMatrix[i][j]/quantizationTable[i][j]);
            }
//unnecessary__________________

        double[][] temp = new double[N][N];
        for(int i =0;i<N;i++){
            for (int j=0;j<N;j++){
                temp[i][j]= result[i][j];
            }
        }

        printResult(temp,"initialize Quantization");
//_____________________________

        return result;
    }

    protected double [][] initializeInverseQuantization(int [][] quantized){

        double[][] result = new double[N][N];
        for(int i=0;i<N;i++)
            for(int j=0;j<N;j++){
                result[i][j]= (int) (quantized[i][j]*quantizationTable[i][j]);
            }

        //unnecessary

        printResult(result,"inverse Quantization");


        return result;

    }

    protected final double[][] applyIDCT(double[][] input)
    {
        final int N = input.length;
        final double mathPI = Math.PI;
        final int halfN = N/2;
        final double doubN = 2.0*N;

        double[][] c = new double[N][N];
        //c = initCoefficients(c);

        double[][] output = new double[N][N];


        for (int x=0; x<N; x++)
        {
            int temp_x = 2*x+1;
            for (int y=0; y<N; y++)
            {
                int temp_y = 2*y+1;
                double sum = 0.0;
                for (int u=0; u<N; u++)
                {
                    double temp_u = u*Math.PI;
                    for (int v=0; v<N; v++)
                    {
                        sum += Ci[u]*Cj[v] * input[u][v] * Math.cos((temp_x/doubN)*temp_u) * Math.cos((temp_y/doubN)*v*Math.PI);
                    }
                }
                //sum /= halfN;
                output[x][y] = sum;
            }
        }

        //unnecessary
        printResult(output,"IDCT");

        BufferedImage idctImage = new BufferedImage(8,8,BufferedImage.TYPE_BYTE_GRAY);

        //set host image
        for(int i =0;i<N;i++){
            for (int j=0;j<N;j++){
                idctImage.setRGB(i,j, (int) output[i][j]);
            }

        }

        try {
            ImageIO.write(idctImage,"jpg",new File("userResources/idctImage_8x8.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return output;
    }



    private void printResult(double[][] output, String methodName){
/*
        System.out.println("--------------------------------------");
        System.out.println("------------"+methodName+"------------");
        for(int i=0;i<N;i++) {
            for (int j = 0; j < N; j++) {

                System.out.print((int) output[i][j]+"  ");
            }
            System.out.println();
        }
        System.out.println("--------------------------------------");


 */
    }



}
